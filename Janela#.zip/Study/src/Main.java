public class Main {
    public static void main(String[] args) {
        Janela janela = new Janela();
        janela.Janela1();
    }
}