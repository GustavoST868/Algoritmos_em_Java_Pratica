import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {

        //objeto da classe banco de dados
        Janela janela = new Janela();
        janela.Janela();


    }

}