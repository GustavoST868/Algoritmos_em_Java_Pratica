package controller;

import view.Janela;

public class Main {
    public static void main(String[] args) {
        Janela janela = new Janela();
    }
}