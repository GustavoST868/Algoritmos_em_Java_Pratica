package controller;

import view.Janela;

public class Main {
    public static void main(String[] args) {
        // chamando a janela
        Janela janel = new Janela();
    }
}
