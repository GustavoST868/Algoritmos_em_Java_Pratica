
public class Main {

    public static void main(String[] args) {

        // objeto da janela
        Janela j = new Janela();

        // chamando a janela
        j.Aplicacao();

    }

}
