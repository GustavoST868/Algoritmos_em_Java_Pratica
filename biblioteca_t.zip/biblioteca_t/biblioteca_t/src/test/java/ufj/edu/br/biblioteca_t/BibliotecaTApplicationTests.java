package ufj.edu.br.biblioteca_t;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaTApplicationTests {

	@Test
	void contextLoads() {
	}

}
